#ifndef MONTHLYCOST_H
#define MONTHLYCOST_H
#include <cmath>

double monthtlycost (int l, double r, int n);

#endif // MONTHLYCOST_H
